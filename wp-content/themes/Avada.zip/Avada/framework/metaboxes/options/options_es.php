<?php

$this->text( 'caption_1', __( 'Title', 'Avada' ), '' );
$this->text( 'caption_2', __( 'Caption', 'Avada' ), '' );

?>
<div class="clear"></div>
